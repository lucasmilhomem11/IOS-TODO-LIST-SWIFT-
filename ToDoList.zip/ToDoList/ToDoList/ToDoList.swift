//
//  ToDoList.swift
//  ToDoList
//
//  Created by student on 4/23/21.
//

import Foundation

struct ToDoList
{
    var table = Array<String>()
    

    
    
}


